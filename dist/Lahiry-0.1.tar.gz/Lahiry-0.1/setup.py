from setuptools import setup

setup(name='Lahiry',
      version='0.1',
      packages=['dev_aberto'],
      install_requires=['requests'],
      scripts=['scripts/hello.py']
 )